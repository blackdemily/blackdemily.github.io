#include "CourseRepository.h"
#include "DatabaseConfig.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iostream>
#include <stdexcept>

std::string CourseRepository::trim(const std::string& s) {
    const auto start = s.find_first_not_of(" \t\r\n");
    const auto end   = s.find_last_not_of(" \t\r\n");
    if (start == std::string::npos || end == std::string::npos) return "";
    return s.substr(start, end - start + 1);
}

bool CourseRepository::isLoaded() const { return loaded_; }

void CourseRepository::loadFromCsv(const std::string& fileName) {
    std::ifstream file(fileName);
    if (!file.is_open()) {
        throw std::runtime_error("Unable to open file: " + fileName);
    }

    byId_.clear();
    std::string line;
    int lineNumber = 0;

    while (std::getline(file, line)) {
        ++lineNumber;
        if (line.empty()) continue;

        std::stringstream ss(line);
        std::string token;
        std::vector<std::string> tokens;

        while (std::getline(ss, token, ',')) {
            tokens.push_back(trim(token));
        }

        if (tokens.size() < 2) {
            std::cerr << "[WARN] Line " << lineNumber
                      << " missing course_id or title. Skipping.\n";
            continue;
        }

        const std::string courseId    = tokens[0];
        const std::string courseTitle = tokens[1];

        Course c(courseId, courseTitle);
        for (std::size_t i = 2; i < tokens.size(); ++i) {
            c.addPrerequisite(tokens[i]);
        }

        byId_[courseId] = c;
    }

    loaded_ = true;
    std::cout << "[INFO] Loaded " << byId_.size()
              << " courses from '" << fileName << "'.\n";
}

const Course* CourseRepository::getCourseById(const std::string& id) const {
    const auto it = byId_.find(id);
    return (it == byId_.end() ? nullptr : &it->second);
}

std::vector<Course> CourseRepository::getAllCoursesSorted() const {
    std::vector<Course> out;
    out.reserve(byId_.size());
    for (const auto& kv : byId_) out.push_back(kv.second);

    std::sort(out.begin(), out.end(),
              [](const Course& a, const Course& b) {
                  return a.getId() < b.getId();
              });
    return out;
}

void CourseRepository::loadFromDatabase() {
    try {
        auto con = db::createConnection();

        // Parameterized SELECT query
        std::unique_ptr<sql::PreparedStatement> pstmt(
            con->prepareStatement(
                "SELECT course_id, title, prereqs FROM courses ORDER BY course_id"
            )
        );

        std::unique_ptr<sql::ResultSet> rs(pstmt->executeQuery());

        // Clear any existing in-memory courses before loading
        // If you use a different container, update this line accordingly.
        byId_.clear(); 

        while (rs->next()) {
            std::string id = rs->getString("course_id");
            std::string title = rs->getString("title");
            std::string prereqStr = rs->isNull("prereqs")
                ? ""
                : rs->getString("prereqs");

            Course c(id, title);

            // Split comma-separated prereqs "CS101,CS200" into vector
            if (!prereqStr.empty()) {
                std::stringstream ss(prereqStr);
                std::string token;
                while (std::getline(ss, token, ',')) {
                    if (!token.empty()) {
                        c.addPrerequisite(token);
                    }
                }
            }

            // Add the course to the repository using your existing logic
            byId_[id] = c;
        }

        loaded_ = true;
        std::cout << "[INFO] Loaded courses from MySQL database.\n";
    }
    catch (sql::SQLException& ex) {
        std::cerr << "[DB ERROR] " << ex.what()
            << " (code: " << ex.getErrorCode()
            << ", SQLState: " << ex.getSQLStateCStr() << ")\n";
    }
}

void CourseRepository::saveCourseToDatabase(const Course& course) {
    try {
        auto con = db::createConnection();

        // Parameterized INSERT with upsert on primary key
        std::unique_ptr<sql::PreparedStatement> pstmt(
            con->prepareStatement(
                "INSERT INTO courses (course_id, title, prereqs) "
                "VALUES (?, ?, ?) "
                "ON DUPLICATE KEY UPDATE title = VALUES(title), prereqs = VALUES(prereqs)"
            )
        );

        pstmt->setString(1, course.getId());
        pstmt->setString(2, course.getTitle());

        const auto& prereqs = course.getPrerequisites();
        if (prereqs.empty()) {
            pstmt->setNull(3, sql::DataType::VARCHAR);
        }
        else {
            std::string joined;
            for (std::size_t i = 0; i < prereqs.size(); ++i) {
                joined += prereqs[i];
                if (i + 1 < prereqs.size()) joined += ",";
            }
            pstmt->setString(3, joined);
        }

        pstmt->executeUpdate();
    }
    catch (sql::SQLException& ex) {
        std::cerr << "[DB ERROR] " << ex.what()
            << " (code: " << ex.getErrorCode()
            << ", SQLState: " << ex.getSQLStateCStr() << ")\n";
    }
}

