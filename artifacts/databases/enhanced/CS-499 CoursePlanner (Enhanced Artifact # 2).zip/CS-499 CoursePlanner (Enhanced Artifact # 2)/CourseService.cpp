#include "CourseService.h"
#include <iostream>

CourseService::CourseService(const CourseRepository& repo)
    : repo_(repo) {}

void CourseService::printCourseList() const {
    const auto all = repo_.getAllCoursesSorted();
    if (all.empty()) {
        std::cout << "No courses available. Please load data first.\n";
        return;
    }

    std::cout << "\nCourse List\n";
    std::cout << "-----------------------------------------\n";
    for (const auto& c : all) {
        std::cout << c.getId() << ", " << c.getTitle() << "\n";
    }
    std::cout << "-----------------------------------------\n\n";
}

void CourseService::printCourseDetails(const std::string& courseId) const {
    const Course* course = repo_.getCourseById(courseId);
    if (!course) {
        std::cout << "Course '" << courseId << "' not found.\n";
        return;
    }

    std::cout << "\nCourse Details\n";
    std::cout << course->getId() << ", " << course->getTitle() << "\n";

    const auto& prereqs = course->getPrerequisites();
    if (prereqs.empty()) {
        std::cout << "Prerequisites: None\n\n";
    } else {
        std::cout << "Prerequisites: ";
        for (std::size_t i = 0; i < prereqs.size(); ++i) {
            std::cout << prereqs[i] << (i + 1 < prereqs.size() ? ", " : "");
        }
        std::cout << "\n\n";
    }
}
