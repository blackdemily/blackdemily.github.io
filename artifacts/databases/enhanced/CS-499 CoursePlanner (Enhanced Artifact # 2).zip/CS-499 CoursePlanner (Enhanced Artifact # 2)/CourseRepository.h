#ifndef COURSE_REPOSITORY_H
#define COURSE_REPOSITORY_H

/**
 * @file CourseRepository.h
 * @brief Data access layer for loading and retrieving Course objects.
 */

#include "Course.h"
#include <string>
#include <unordered_map>
#include <vector>
#include <map>

/**
 * @class CourseRepository
 * @brief Responsible for loading courses from CSV and serving lookups.
 *
 * Responsibilities:
 *  - Load courses from CSV or MySQL database.
 *  - Provide fast lookups by course ID.
 *  - Provide a sorted view of all courses.
 */
class CourseRepository {
private:
    std::unordered_map<std::string, Course> byId_;
    bool loaded_{false};

    static std::string trim(const std::string& s);

public:
    bool isLoaded() const;

    // Throws std::runtime_error on failure to open file.
    void loadFromCsv(const std::string& fileName);

    const Course* getCourseById(const std::string& id) const;
    std::vector<Course> getAllCoursesSorted() const;

    // load and save using MySQL
    void loadFromDatabase();
    void saveCourseToDatabase(const Course& course);
};

#endif // COURSE_REPOSITORY_H
