#ifndef COURSE_H
#define COURSE_H

/**
 * @file Course.h
 * @brief Domain model for a course with ID, title, and a list of prerequisite IDs.
 */

#include <string>
#include <vector>

/**
 * @class Course
 * @brief Encapsulates course data and enforces basic invariants.
 *
 * Design notes:
 *  - Members are private to support encapsulation.
 *  - Access via const getters to support read only flows across layers.
 */
class Course {
private:
    std::string id_;
    std::string title_;
    std::vector<std::string> prereqs_;

public:
    Course() = default;
    Course(const std::string& id, const std::string& title);

    const std::string& getId() const;
    const std::string& getTitle() const;
    const std::vector<std::string>& getPrerequisites() const;

    void addPrerequisite(const std::string& prereqId);
};

#endif // COURSE_H
