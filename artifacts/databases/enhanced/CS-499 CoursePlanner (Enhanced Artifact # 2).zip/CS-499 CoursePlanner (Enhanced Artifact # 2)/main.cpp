#include "MenuUI.h"
#include "CourseRepository.h"
#include <exception>
#include <iostream>

int main() {
    try {
        CourseRepository repository;
        MenuUI ui(repository);
        ui.run();
    }
    catch (const std::exception& ex) {
        std::cerr << "[FATAL] Unexpected error: " << ex.what() << "\n";
        return 1;
    }
    return 0;
}
