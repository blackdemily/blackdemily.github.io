#include "MenuUI.h"
#include <iostream>
#include <limits>
#include <string>

MenuUI::MenuUI(CourseRepository& repo)
    : repo_(repo), service_(repo) {}

void MenuUI::printMenu() {
    std::cout << "================ Course Planner ================\n";
    std::cout << "  1. Load Data Structure\n";
    std::cout << "  2. Print Course List\n";
    std::cout << "  3. Print Course\n";
    std::cout << "  9. Exit\n";
    std::cout << "================================================\n";
    std::cout << "Enter your choice: ";
}

int MenuUI::readIntChoice() {
    int choice;
    while (true) {
        if (std::cin >> choice) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return choice;
        } else {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number: ";
        }
    }
}

void MenuUI::run() {
    bool running = true;
    while (running) {
        printMenu();
        const int choice = readIntChoice();

        switch (choice) {
            case 1: {
                std::cout << "Load courses from:\n";
                std::cout << "  1. CSV file\n";
                std::cout << "  2. MySQL database\n";
                std::cout << "Enter your choice: ";

                int subChoice = readIntChoice();

                if (subChoice == 1) {
                    std::cout << "Enter CSV file name (for example, courses.csv): ";
                    std::string fileName;
                    std::getline(std::cin, fileName);

                    try {
                        repo_.loadFromCsv(fileName);
                    }
                    catch (const std::exception& ex) {
                        std::cerr << "[ERROR] " << ex.what() << "\n";
                    }
                }
                else if (subChoice == 2) {
                    try {
                        repo_.loadFromDatabase();
                    }
                    catch (const std::exception& ex) {
                        std::cerr << "[ERROR] Unable to load from database: " << ex.what() << "\n";
                    }
                }
                else {
                    std::cout << "Invalid option.\n";
                }

                break;
            }
            case 2:
                if (!repo_.isLoaded()) {
                    std::cout << "Please load course data first.\n";
                } else {
                    service_.printCourseList();
                }
                break;
            case 3:
                if (!repo_.isLoaded()) {
                    std::cout << "Please load course data first.\n";
                } else {
                    std::cout << "Enter course ID: ";
                    std::string id;
                    std::getline(std::cin, id);
                    service_.printCourseDetails(id);
                }
                break;
            case 9:
                std::cout << "Exiting Course Planner. Goodbye.\n";
                running = false;
                break;
            default:
                std::cout << "Invalid choice. Please select 1, 2, 3, or 9.\n";
                break;
        }
    }
}
