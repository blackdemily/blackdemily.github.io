#pragma once

#include <memory>
#include <string>

// MySQL Connector/C++ headers (JDBC-style API)
#include <jdbc/mysql_driver.h>
#include <jdbc/mysql_connection.h>
#include <jdbc/cppconn/prepared_statement.h>
#include <jdbc/cppconn/resultset.h>
#include <jdbc/cppconn/exception.h>

namespace db {

    /**
    * Create a new MySQL connection to the course_planner_db schema.
    * Note: Credentials are hard-coded only for this local capstone project.
    * In production, they would be stored securely (env variables or config files).
    */

    inline std::shared_ptr<sql::Connection> createConnection() {
        const std::string url = "tcp://127.0.0.1:3306";
        const std::string user = "root";            
        const std::string pass = "EBRootPass123!";  
        const std::string schema = "course_planner_db";

        sql::mysql::MySQL_Driver* driver = sql::mysql::get_mysql_driver_instance();
        std::shared_ptr<sql::Connection> con(driver->connect(url, user, pass));
        con->setSchema(schema);
        return con;
    }

}
