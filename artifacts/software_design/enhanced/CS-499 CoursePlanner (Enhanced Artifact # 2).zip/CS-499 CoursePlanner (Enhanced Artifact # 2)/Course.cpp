#include "Course.h"

Course::Course(const std::string& id, const std::string& title)
    : id_(id), title_(title) {}

const std::string& Course::getId() const { return id_; }
const std::string& Course::getTitle() const { return title_; }
const std::vector<std::string>& Course::getPrerequisites() const { return prereqs_; }

void Course::addPrerequisite(const std::string& prereqId) {
    if (!prereqId.empty()) {
        prereqs_.push_back(prereqId);
    }
}
