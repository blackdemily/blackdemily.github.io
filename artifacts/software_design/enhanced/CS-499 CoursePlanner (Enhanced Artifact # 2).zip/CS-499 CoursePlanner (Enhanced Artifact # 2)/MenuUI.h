#ifndef MENU_UI_H
#define MENU_UI_H

/**
 * @file MenuUI.h
 * @brief Console user interface for the Course Planner.
 */

#include "CourseRepository.h"
#include "CourseService.h"

class MenuUI {
private:
    CourseRepository& repo_;
    CourseService service_;

    static void printMenu();
    static int readIntChoice();

public:
    explicit MenuUI(CourseRepository& repo);

    // Drives the console menu loop.
    void run();
};

#endif // MENU_UI_H
