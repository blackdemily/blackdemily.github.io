#ifndef COURSE_SERVICE_H
#define COURSE_SERVICE_H

/**
 * @file CourseService.h
 * @brief Business logic for formatting and presenting course data.
 */

#include "CourseRepository.h"
#include <string>

class CourseService {
private:
    const CourseRepository& repo_;

public:
    explicit CourseService(const CourseRepository& repo);

    void printCourseList() const;
    void printCourseDetails(const std::string& courseId) const;
};

#endif // COURSE_SERVICE_H
